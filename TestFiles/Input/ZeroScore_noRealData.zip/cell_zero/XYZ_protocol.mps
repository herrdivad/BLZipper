MPS XYZ protocol -- noRealData (no prefix match)
