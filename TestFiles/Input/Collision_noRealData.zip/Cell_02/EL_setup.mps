MPS belongs to Cell_02 -- DIFFERENT -- noRealData
