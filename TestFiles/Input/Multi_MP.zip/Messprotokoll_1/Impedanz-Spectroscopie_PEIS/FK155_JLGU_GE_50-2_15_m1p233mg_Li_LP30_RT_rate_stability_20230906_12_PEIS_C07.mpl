EC-Lab LOG FILE

Potentio Electrochemical Impedance Spectroscopy

Run on channel : 7 (SN 67339)
User : 
CE vs. WE compliance from -10 V to 10 V
Electrode connection : standard
Potential control : Ewe
Ewe ctrl range : min = -10.00 V, max = 10.00 V
Safety Limits :
	Do not start on E overload
Acquisition started on : 09/06/2023 15:18:20.995
Loaded Setting File : D:\Fabian\LiBOB in EiPS\Graphite half cell\FK125_JLGU_GE_LP30_RateAndCyclab_1p26mg_PlOldPress_090823\FK125_JLGU_GE_LP30_RateAndCyclab_1p26mg_PlOldPress_090823.mps
Saved on :
	File : FK155_JLGU_GE_50-2_15_m1p233mg_Li_LP30_RT_rate_stability_20230906_12_PEIS_C07.mpr
	Directory : D:\Fabian\LiBOB in EiPS\Graphite half cell\FK155_JLGU_GE_50-2_15_m1p233mg_Li_LP30_RT_rate_stability_20230906\
	Host : 192.109.209.100
Device : MPG-2 (SN 0328)
Address : 192.109.209.99
EC-Lab for windows v11.43 (software)
Internet server v11.40 (firmware)
Command interpretor v11.40 (firmware)
Electrode material : GE (S�dchemie)
Initial state : discharged
Electrolyte : LP30
Comments : 60�C
Comments : rate + cyclability
Mass of active material : 1.260 mg
 at x = 0.000
Molecular weight of active material (at x = 0) : 0.001 g/mol
Atomic weight of intercalated ion : 0.001 g/mol
Acquisition started at : xo = 0.000
Number of e- transfered per intercalated ion : 1
for DX = 1, DQ = 33769.888 mA.h
Battery capacity : 0.458 mA.h
Reference electrode : Li/Li+ (3.050 V)
Electrode surface area : 1.130 cm�
Characteristic mass : 1.260 mg
Volume (V) : 0.001 cm�
Cycle Definition : Charge/Discharge alternance
Mode                Single sine         
E (V)               0.0000              
vs.                 Eoc                 
tE (h:m:s)          1:00:0.0000         
record              0                   
dI                  0.000               
unit dI             mA                  
dt (s)              30.000              
fi                  100.000             
unit fi             kHz                 
ff                  10.000              
unit ff             mHz                 
Nd                  30                  
Points              per decade          
spacing             Logarithmic         
Va (mV)             10.0                
pw                  0.10                
Na                  2                   
corr                0                   
E range min (V)     -10.000             
E range max (V)     10.000              
I Range             Auto                
Bandwidth           5                   
nc cycles           0                   
goto Ns'            0                   
nr cycles           0                   
inc. cycle          0                   

Modify on : 09/19/2023 12:11
Electrode material : GE (S�dchemie)
Initial state : discharged
Electrolyte : LP30
Comments : 60�C
Comments : rate + cyclability
Mass of active material : 1.260 mg
for DX = 1, DQ = 33769.888 mA.h
Battery capacity : 0.458 mA.h
Reference electrode : Li/Li+ (3.050 V)
Electrode surface area : 1.130 cm�
Characteristic mass : 1.260 mg
