EC-LAB SETTING FILE

Number of linked techniques : 12

EC-LAB for windows v11.43 (software)
Internet server v11.40 (firmware)
Command interpretor v11.40 (firmware)

Filename : D:\Fabian\LiBOB in EiPS\Graphite half cell\FK155_JLGU_GE_50-2_15_m1p233mg_Li_LP30_RT_rate_stability_20230906\FK155_JLGU_GE_50-2_15_m1p233mg_Li_LP30_RT_rate_stability_20230906.mps

Device : MPG-2
CE vs. WE compliance from -10 V to 10 V
Electrode connection : standard
Potential control : Ewe
Ewe ctrl range : min = -10.00 V, max = 10.00 V
Safety Limits :
	Do not start on E overload
Electrode material : GE (S�dchemie)
Initial state : discharged
Electrolyte : LP30
Comments : 60�C
Comments : rate + cyclability
Mass of active material : 1.260 mg
 at x = 0.000
Molecular weight of active material (at x = 0) : 0.001 g/mol
Atomic weight of intercalated ion : 0.001 g/mol
Acquisition started at : xo = 0.000
Number of e- transfered per intercalated ion : 1
for DX = 1, DQ = 33769.888 mA.h
Battery capacity : 0.458 mA.h
Reference electrode : Li/Li+ (3.050 V)
Electrode surface area : 1.130 cm�
Characteristic mass : 1.260 mg
Volume (V) : 0.001 cm�
Cycle Definition : Charge/Discharge alternance
Turn to OCV between techniques

Technique : 1
Open Circuit Voltage
tR (h:m:s)          5:00:0.0000         
dER/dt (mV/h)       0.0                 
record              <Ewe>               
dER (mV)            0.00                
dtR (s)             30.0000             
E range min (V)     -10.000             
E range max (V)     10.000              

Technique : 2
Galvanostatic Cycling with Potential Limitation
Ns                  0                   1                   2                   
Set I/C             I                   C x N               C x N               
Is                  0.000               -0.037              0.037               
unit Is             mA                  mA                  mA                  
vs.                 <None>              <None>              <None>              
N                   1.00                0.05                0.05                
I sign              < 0                 < 0                 > 0                 
t1 (h:m:s)          0:00:0.0000         1000:00:0.0000      1000:00:0.0000      
I Range             100 �A              10 �A               10 �A               
Bandwidth           5                   5                   5                   
dE1 (mV)            0.00                10.00               10.00               
dt1 (s)             0.0000              10.0000             10.0000             
EM (V)              0.000               0.005               2.000               
tM (h:m:s)          0:00:0.0000         0:00:0.0000         0:00:0.0000         
Im                  0.000               0.000               0.000               
unit Im             mA                  mA                  mA                  
dI/dt               0.000               0.000               0.000               
dunit dI/dt         mA/s                mA/s                mA/s                
E range min (V)     -10.000             -10.000             -10.000             
E range max (V)     10.000              10.000              10.000              
dq                  0.000               1.000               1.000               
unit dq             mA.h                mA.h                mA.h                
dtq (s)             0.0000              120.0000            120.0000            
dQM                 0.000               0.000               0.000               
unit dQM            mA.h                mA.h                mA.h                
dxM                 0.000               0.000               0.000               
delta SoC (%)       pass                pass                pass                
tR (h:m:s)          0:00:0.0000         0:00:0.0000         0:00:0.0000         
dER/dt (mV/h)       0.0                 0.1                 0.0                 
dER (mV)            0.00                0.00                0.00                
dtR (s)             2.0000              120.0000            120.0000            
EL (V)              pass                4.200               3.500               
goto Ns'            0                   0                   0                   
nc cycles           0                   0                   0                   

Technique : 3
Galvanostatic Cycling with Potential Limitation
Ns                  0                   1                   2                   
Set I/C             I                   C x N               C x N               
Is                  0.000               10.000              -10.000             
unit Is             mA                  mA                  mA                  
vs.                 <None>              <None>              <None>              
N                   1.00                0.10                0.10                
I sign              < 0                 < 0                 > 0                 
t1 (h:m:s)          0:00:0.0000         20:00:0.0000        20:00:0.0000        
I Range             100 �A              100 �A              100 �A              
Bandwidth           5                   5                   5                   
dE1 (mV)            0.00                10.00               10.00               
dt1 (s)             0.0000              10.0000             10.0000             
EM (V)              0.000               0.005               2.000               
tM (h:m:s)          0:00:0.0000         0:00:0.0000         0:00:0.0000         
Im                  0.000               0.000               0.000               
unit Im             mA                  mA                  mA                  
dI/dt               0.000               0.000               0.000               
dunit dI/dt         mA/s                mA/s                mA/s                
E range min (V)     -10.000             -10.000             -10.000             
E range max (V)     10.000              10.000              10.000              
dq                  0.000               1.000               1.000               
unit dq             mA.h                mA.h                mA.h                
dtq (s)             0.0000              120.0000            120.0000            
dQM                 0.000               0.000               0.000               
unit dQM            mA.h                mA.h                mA.h                
dxM                 0.000               0.000               0.000               
delta SoC (%)       pass                pass                pass                
tR (h:m:s)          0:00:10.0000        0:00:0.0000         0:00:0.0000         
dER/dt (mV/h)       0.0                 0.1                 0.1                 
dER (mV)            0.00                0.00                0.00                
dtR (s)             1.0000              120.0000            120.0000            
EL (V)              pass                4.200               3.500               
goto Ns'            0                   0                   1                   
nc cycles           0                   0                   4                   

Technique : 4
Galvanostatic Cycling with Potential Limitation
Ns                  0                   1                   2                   
Set I/C             I                   C x N               C x N               
Is                  0.000               10.000              -10.000             
unit Is             mA                  mA                  mA                  
vs.                 <None>              <None>              <None>              
N                   1.00                0.20                0.20                
I sign              < 0                 < 0                 > 0                 
t1 (h:m:s)          0:00:0.0000         10:00:0.0000        10:00:0.0000        
I Range             100 �A              100 �A              100 �A              
Bandwidth           5                   5                   5                   
dE1 (mV)            0.00                10.00               10.00               
dt1 (s)             0.0000              10.0000             10.0000             
EM (V)              0.000               0.005               2.000               
tM (h:m:s)          0:00:0.0000         0:00:0.0000         0:00:0.0000         
Im                  0.000               0.000               0.000               
unit Im             mA                  mA                  mA                  
dI/dt               0.000               0.000               0.000               
dunit dI/dt         mA/s                mA/s                mA/s                
E range min (V)     -10.000             -10.000             -10.000             
E range max (V)     10.000              10.000              10.000              
dq                  0.000               1.000               1.000               
unit dq             mA.h                mA.h                mA.h                
dtq (s)             0.0000              120.0000            120.0000            
dQM                 0.000               0.000               0.000               
unit dQM            mA.h                mA.h                mA.h                
dxM                 0.000               0.000               0.000               
delta SoC (%)       pass                pass                pass                
tR (h:m:s)          0:00:10.0000        0:00:0.0000         0:00:0.0000         
dER/dt (mV/h)       0.0                 0.1                 0.1                 
dER (mV)            0.00                0.00                0.00                
dtR (s)             1.0000              120.0000            120.0000            
EL (V)              pass                4.200               3.500               
goto Ns'            0                   0                   1                   
nc cycles           0                   0                   4                   

Technique : 5
Galvanostatic Cycling with Potential Limitation
Ns                  0                   1                   2                   
Set I/C             I                   C x N               C x N               
Is                  0.000               10.000              -10.000             
unit Is             mA                  mA                  mA                  
vs.                 <None>              <None>              <None>              
N                   1.00                0.50                0.50                
I sign              < 0                 < 0                 > 0                 
t1 (h:m:s)          0:00:0.0000         10:00:0.0000        10:00:0.0000        
I Range             100 �A              100 �A              100 �A              
Bandwidth           5                   5                   5                   
dE1 (mV)            0.00                10.00               10.00               
dt1 (s)             0.0000              10.0000             10.0000             
EM (V)              0.000               0.005               2.000               
tM (h:m:s)          0:00:0.0000         0:00:0.0000         0:00:0.0000         
Im                  0.000               0.000               0.000               
unit Im             mA                  mA                  mA                  
dI/dt               0.000               0.000               0.000               
dunit dI/dt         mA/s                mA/s                mA/s                
E range min (V)     -10.000             -10.000             -10.000             
E range max (V)     10.000              10.000              10.000              
dq                  0.000               1.000               1.000               
unit dq             mA.h                mA.h                mA.h                
dtq (s)             0.0000              120.0000            120.0000            
dQM                 0.000               0.000               0.000               
unit dQM            mA.h                mA.h                mA.h                
dxM                 0.000               0.000               0.000               
delta SoC (%)       pass                pass                pass                
tR (h:m:s)          0:00:10.0000        0:00:0.0000         0:00:0.0000         
dER/dt (mV/h)       0.0                 0.1                 0.1                 
dER (mV)            0.00                0.00                0.00                
dtR (s)             1.0000              120.0000            120.0000            
EL (V)              pass                4.200               3.500               
goto Ns'            0                   0                   1                   
nc cycles           0                   0                   4                   

Technique : 6
Galvanostatic Cycling with Potential Limitation
Ns                  0                   1                   2                   
Set I/C             I                   C x N               C x N               
Is                  0.000               10.000              -10.000             
unit Is             mA                  mA                  mA                  
vs.                 <None>              <None>              <None>              
N                   1.00                1.00                1.00                
I sign              < 0                 < 0                 > 0                 
t1 (h:m:s)          0:00:0.0000         10:00:0.0000        10:00:0.0000        
I Range             1 mA                1 mA                1 mA                
Bandwidth           5                   5                   5                   
dE1 (mV)            0.00                10.00               10.00               
dt1 (s)             0.0000              10.0000             10.0000             
EM (V)              0.000               0.005               2.000               
tM (h:m:s)          0:00:0.0000         0:00:0.0000         0:00:0.0000         
Im                  0.000               0.000               0.000               
unit Im             mA                  mA                  mA                  
dI/dt               0.000               0.000               0.000               
dunit dI/dt         mA/s                mA/s                mA/s                
E range min (V)     -10.000             -10.000             -10.000             
E range max (V)     10.000              10.000              10.000              
dq                  0.000               1.000               1.000               
unit dq             mA.h                mA.h                mA.h                
dtq (s)             0.0000              120.0000            120.0000            
dQM                 0.000               0.000               0.000               
unit dQM            mA.h                mA.h                mA.h                
dxM                 0.000               0.000               0.000               
delta SoC (%)       pass                pass                pass                
tR (h:m:s)          0:00:10.0000        0:00:0.0000         0:00:0.0000         
dER/dt (mV/h)       0.0                 0.1                 0.1                 
dER (mV)            0.00                0.00                0.00                
dtR (s)             1.0000              120.0000            120.0000            
EL (V)              pass                4.200               3.500               
goto Ns'            0                   0                   1                   
nc cycles           0                   0                   4                   

Technique : 7
Galvanostatic Cycling with Potential Limitation
Ns                  0                   1                   2                   
Set I/C             I                   C x N               C x N               
Is                  0.000               10.000              -10.000             
unit Is             mA                  mA                  mA                  
vs.                 <None>              <None>              <None>              
N                   1.00                2.00                2.00                
I sign              > 0                 < 0                 > 0                 
t1 (h:m:s)          0:00:0.0000         10:00:0.0000        10:00:0.0000        
I Range             10 mA               1 mA                1 mA                
Bandwidth           5                   5                   5                   
dE1 (mV)            0.00                10.00               10.00               
dt1 (s)             0.0000              10.0000             10.0000             
EM (V)              0.000               0.005               2.000               
tM (h:m:s)          0:00:0.0000         0:00:0.0000         0:00:0.0000         
Im                  0.000               0.000               0.000               
unit Im             mA                  mA                  mA                  
dI/dt               0.000               0.000               0.000               
dunit dI/dt         mA/s                mA/s                mA/s                
E range min (V)     -10.000             -10.000             -10.000             
E range max (V)     10.000              10.000              10.000              
dq                  0.000               1.000               1.000               
unit dq             mA.h                mA.h                mA.h                
dtq (s)             0.0000              120.0000            120.0000            
dQM                 0.000               0.000               0.000               
unit dQM            mA.h                mA.h                mA.h                
dxM                 0.000               0.000               0.000               
delta SoC (%)       pass                pass                pass                
tR (h:m:s)          0:00:10.0000        0:00:0.0000         0:00:0.0000         
dER/dt (mV/h)       0.0                 0.1                 0.1                 
dER (mV)            0.00                0.00                0.00                
dtR (s)             1.0000              120.0000            120.0000            
EL (V)              pass                4.200               3.500               
goto Ns'            0                   0                   1                   
nc cycles           0                   0                   4                   

Technique : 8
Galvanostatic Cycling with Potential Limitation
Ns                  0                   1                   2                   
Set I/C             I                   C x N               C x N               
Is                  0.000               10.000              -10.000             
unit Is             mA                  mA                  mA                  
vs.                 <None>              <None>              <None>              
N                   1.00                5.00                5.00                
I sign              > 0                 < 0                 > 0                 
t1 (h:m:s)          0:00:0.0000         10:00:0.0000        10:00:0.0000        
I Range             10 mA               1 mA                1 mA                
Bandwidth           5                   5                   5                   
dE1 (mV)            0.00                10.00               10.00               
dt1 (s)             0.0000              10.0000             10.0000             
EM (V)              0.000               0.005               2.000               
tM (h:m:s)          0:00:0.0000         0:00:0.0000         0:00:0.0000         
Im                  0.000               0.000               0.000               
unit Im             mA                  mA                  mA                  
dI/dt               0.000               0.000               0.000               
dunit dI/dt         mA/s                mA/s                mA/s                
E range min (V)     -10.000             -10.000             -10.000             
E range max (V)     10.000              10.000              10.000              
dq                  0.000               1.000               1.000               
unit dq             mA.h                mA.h                mA.h                
dtq (s)             0.0000              120.0000            120.0000            
dQM                 0.000               0.000               0.000               
unit dQM            mA.h                mA.h                mA.h                
dxM                 0.000               0.000               0.000               
delta SoC (%)       pass                pass                pass                
tR (h:m:s)          0:00:10.0000        0:00:0.0000         0:00:0.0000         
dER/dt (mV/h)       0.0                 0.1                 0.1                 
dER (mV)            0.00                0.00                0.00                
dtR (s)             1.0000              120.0000            120.0000            
EL (V)              pass                4.200               3.500               
goto Ns'            0                   0                   1                   
nc cycles           0                   0                   4                   

Technique : 9
Galvanostatic Cycling with Potential Limitation
Ns                  0                   1                   2                   
Set I/C             I                   C x N               C x N               
Is                  0.000               10.000              -10.000             
unit Is             mA                  mA                  mA                  
vs.                 <None>              <None>              <None>              
N                   1.00                0.10                0.10                
I sign              < 0                 < 0                 > 0                 
t1 (h:m:s)          0:00:0.0000         20:00:0.0000        20:00:0.0000        
I Range             100 �A              100 �A              100 �A              
Bandwidth           5                   5                   5                   
dE1 (mV)            0.00                10.00               10.00               
dt1 (s)             0.0000              10.0000             10.0000             
EM (V)              0.000               0.005               2.000               
tM (h:m:s)          0:00:0.0000         0:00:0.0000         0:00:0.0000         
Im                  0.000               0.000               0.000               
unit Im             mA                  mA                  mA                  
dI/dt               0.000               0.000               0.000               
dunit dI/dt         mA/s                mA/s                mA/s                
E range min (V)     -10.000             -10.000             -10.000             
E range max (V)     10.000              10.000              10.000              
dq                  0.000               1.000               1.000               
unit dq             mA.h                mA.h                mA.h                
dtq (s)             0.0000              120.0000            120.0000            
dQM                 0.000               0.000               0.000               
unit dQM            mA.h                mA.h                mA.h                
dxM                 0.000               0.000               0.000               
delta SoC (%)       pass                pass                pass                
tR (h:m:s)          0:00:10.0000        0:00:0.0000         0:00:0.0000         
dER/dt (mV/h)       0.0                 0.1                 0.1                 
dER (mV)            0.00                0.00                0.00                
dtR (s)             1.0000              120.0000            120.0000            
EL (V)              pass                4.200               3.500               
goto Ns'            0                   0                   1                   
nc cycles           0                   0                   4                   

Technique : 10
Potentio Electrochemical Impedance Spectroscopy
Mode                Single sine         
E (V)               0.0000              
vs.                 Eoc                 
tE (h:m:s)          1:00:0.0000         
record              0                   
dI                  0.000               
unit dI             mA                  
dt (s)              30.000              
fi                  100.000             
unit fi             kHz                 
ff                  10.000              
unit ff             mHz                 
Nd                  30                  
Points              per decade          
spacing             Logarithmic         
Va (mV)             10.0                
pw                  0.10                
Na                  2                   
corr                0                   
E range min (V)     -10.000             
E range max (V)     10.000              
I Range             Auto                
Bandwidth           5                   
nc cycles           0                   
goto Ns'            0                   
nr cycles           0                   
inc. cycle          0                   

Technique : 11
Galvanostatic Cycling with Potential Limitation
Ns                  0                   1                   2                   
Set I/C             I                   C x N               C x N               
Is                  0.000               10.000              -10.000             
unit Is             mA                  mA                  mA                  
vs.                 <None>              <None>              <None>              
N                   1.00                1.00                1.00                
I sign              < 0                 < 0                 > 0                 
t1 (h:m:s)          0:00:0.0000         10:30:0.0000        10:30:0.0000        
I Range             1 mA                1 mA                1 mA                
Bandwidth           5                   5                   5                   
dE1 (mV)            0.00                10.00               10.00               
dt1 (s)             0.0000              10.0000             10.0000             
EM (V)              0.000               0.005               1.500               
tM (h:m:s)          0:00:0.0000         0:00:0.0000         0:00:0.0000         
Im                  0.000               0.000               0.000               
unit Im             mA                  mA                  mA                  
dI/dt               0.000               0.000               0.000               
dunit dI/dt         mA/s                mA/s                mA/s                
E range min (V)     -10.000             -10.000             -10.000             
E range max (V)     10.000              10.000              10.000              
dq                  0.000               1.000               1.000               
unit dq             mA.h                mA.h                mA.h                
dtq (s)             0.0000              120.0000            120.0000            
dQM                 0.000               0.000               0.000               
unit dQM            mA.h                mA.h                mA.h                
dxM                 0.000               0.000               0.000               
delta SoC (%)       pass                pass                pass                
tR (h:m:s)          0:00:10.0000        0:00:0.0000         0:00:0.0000         
dER/dt (mV/h)       0.0                 0.1                 0.1                 
dER (mV)            0.00                0.00                0.00                
dtR (s)             1.0000              120.0000            120.0000            
EL (V)              pass                4.200               3.500               
goto Ns'            0                   0                   1                   
nc cycles           0                   0                   199                 

Technique : 12
Potentio Electrochemical Impedance Spectroscopy
Mode                Single sine         
E (V)               0.0000              
vs.                 Eoc                 
tE (h:m:s)          1:00:0.0000         
record              0                   
dI                  0.000               
unit dI             mA                  
dt (s)              30.000              
fi                  100.000             
unit fi             kHz                 
ff                  10.000              
unit ff             mHz                 
Nd                  30                  
Points              per decade          
spacing             Logarithmic         
Va (mV)             10.0                
pw                  0.10                
Na                  2                   
corr                0                   
E range min (V)     -10.000             
E range max (V)     10.000              
I Range             Auto                
Bandwidth           5                   
nc cycles           0                   
goto Ns'            0                   
nr cycles           0                   
inc. cycle          0                   
