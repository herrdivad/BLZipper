EC-LAB SETTING FILE

Number of linked techniques : 18

EC-LAB for windows v11.43 (software)
Internet server v11.40 (firmware)
Command interpretor v11.40 (firmware)

Filename : D:\Eleonora\EDLC\EL_2Elec_4p79mg_Et4NBF4inACN_EDLC_Pl2_211024\EL_2Elec_4p79mg_Et4NBF4inACN_EDLC_Pl2_211024.mps

Device : MPG-2
CE vs. WE compliance from -10 V to 10 V
Electrode connection : standard
Potential control : Ewe-Ece
Ewe ctrl range : min = -5.00 V, max = 5.00 V
Safety Limits :
	Do not start on E overload
Electrode material : Activated carbon
Initial state : uncharged
Electrolyte : 1M TEABF4 in ACN
Comments : CV and GCPL
Mass of active material : 1.000 mg
 at x = 1.000
Molecular weight of active material (at x = 0) : 12.000 g/mol
Atomic weight of intercalated ion : 0.001 g/mol
Acquisition started at : xo = 0.000
Number of e- transfered per intercalated ion : 1
for DX = 1, DQ = 2.233 mA.h
Battery capacity : 4.790 mA.h
Electrode surface area : 1.131 cm�
Characteristic mass : 4.790 mg
Volume (V) : 1.131 cm�
Record Ece
Record Power
Cycle Definition : Charge/Discharge alternance
Turn to OCV between techniques

Technique : 1
Open Circuit Voltage
tR (h:m:s)          0:00:10.0000        
dER/dt (mV/h)       0.0                 
record              Ewe                 
dER (mV)            0.00                
dtR (s)             20.0000             
E range min (V)     -5.000              
E range max (V)     5.000               

Technique : 2
Cyclic Voltammetry
Ei (V)              0.000               
vs.                 Emeas               
dE/dt               5.000               
dE/dt unit          mV/s                
E1 (V)              2.700               
vs.                 Ref                 
Step percent        50                  
N                   10                  
E range min (V)     -5.000              
E range max (V)     5.000               
I Range             Auto                
I Range min         Unset               
I Range max         Unset               
I Range init        Unset               
Bandwidth           4                   
E2 (V)              0.000               
vs.                 Ref                 
nc cycles           14                  
Reverse Scan        0                   
Ef (V)              0.000               
vs.                 Eoc                 

Technique : 3
Cyclic Voltammetry
Ei (V)              0.000               
vs.                 Emeas               
dE/dt               10.000              
dE/dt unit          mV/s                
E1 (V)              2.700               
vs.                 Ref                 
Step percent        50                  
N                   10                  
E range min (V)     -5.000              
E range max (V)     5.000               
I Range             Auto                
I Range min         Unset               
I Range max         Unset               
I Range init        Unset               
Bandwidth           4                   
E2 (V)              0.000               
vs.                 Ref                 
nc cycles           9                   
Reverse Scan        0                   
Ef (V)              0.000               
vs.                 Eoc                 

Technique : 4
Cyclic Voltammetry
Ei (V)              0.000               
vs.                 Emeas               
dE/dt               20.000              
dE/dt unit          mV/s                
E1 (V)              2.700               
vs.                 Ref                 
Step percent        50                  
N                   10                  
E range min (V)     -5.000              
E range max (V)     5.000               
I Range             Auto                
I Range min         Unset               
I Range max         Unset               
I Range init        Unset               
Bandwidth           4                   
E2 (V)              0.000               
vs.                 Ref                 
nc cycles           9                   
Reverse Scan        0                   
Ef (V)              0.000               
vs.                 Eoc                 

Technique : 5
Cyclic Voltammetry
Ei (V)              0.000               
vs.                 Emeas               
dE/dt               50.000              
dE/dt unit          mV/s                
E1 (V)              2.700               
vs.                 Ref                 
Step percent        50                  
N                   10                  
E range min (V)     -5.000              
E range max (V)     5.000               
I Range             Auto                
I Range min         Unset               
I Range max         Unset               
I Range init        Unset               
Bandwidth           5                   
E2 (V)              0.000               
vs.                 Ref                 
nc cycles           9                   
Reverse Scan        0                   
Ef (V)              0.000               
vs.                 Eoc                 

Technique : 6
Galvanostatic Cycling with Potential Limitation
Ns                  0                   1                   2                   
Set I/C             I                   C x N               C x N               
Is                  0.000               10.000              -10.000             
unit Is             mA                  mA                  mA                  
vs.                 <None>              <None>              <None>              
N                   1.00                0.25                0.25                
I sign              > 0                 > 0                 < 0                 
t1 (h:m:s)          0:00:0.0000         100:00:0.0000       100:00:0.0000       
I Range             1 mA                1 mA                1 mA                
Bandwidth           5                   5                   5                   
dE1 (mV)            0.00                10.00               10.00               
dt1 (s)             0.0000              10.0000             10.0000             
EM (V)              0.000               2.700               0.000               
tM (h:m:s)          0:00:0.0000         0:00:0.0000         0:00:0.0000         
Im                  0.000               0.000               0.000               
unit Im             mA                  mA                  mA                  
dI/dt               0.000               0.000               0.000               
dunit dI/dt         mA/s                mA/s                mA/s                
E range min (V)     -5.000              -5.000              -5.000              
E range max (V)     5.000               5.000               5.000               
dq                  0.000               1.000               1.000               
unit dq             mA.h                mA.h                mA.h                
dtq (s)             0.0000              120.0000            120.0000            
dQM                 0.000               0.000               0.000               
unit dQM            mA.h                mA.h                mA.h                
dxM                 0.000               0.000               0.000               
delta SoC (%)       pass                pass                pass                
tR (h:m:s)          0:00:10.0000        0:00:0.0000         0:00:0.0000         
dER/dt (mV/h)       0.0                 0.1                 0.1                 
dER (mV)            0.00                0.00                0.00                
dtR (s)             1.0000              120.0000            120.0000            
EL (V)              pass                4.200               3.500               
goto Ns'            0                   0                   1                   
nc cycles           0                   0                   4                   

Technique : 7
Galvanostatic Cycling with Potential Limitation
Ns                  0                   1                   2                   
Set I/C             I                   C x N               C x N               
Is                  0.000               10.000              -10.000             
unit Is             mA                  mA                  mA                  
vs.                 <None>              <None>              <None>              
N                   1.00                0.50                0.50                
I sign              > 0                 > 0                 < 0                 
t1 (h:m:s)          0:00:0.0000         10:00:0.0000        10:00:0.0000        
I Range             1 mA                1 mA                1 mA                
Bandwidth           5                   5                   5                   
dE1 (mV)            0.00                10.00               10.00               
dt1 (s)             0.0000              10.0000             10.0000             
EM (V)              0.000               2.700               0.000               
tM (h:m:s)          0:00:0.0000         0:00:0.0000         0:00:0.0000         
Im                  0.000               0.000               0.000               
unit Im             mA                  mA                  mA                  
dI/dt               0.000               0.000               0.000               
dunit dI/dt         mA/s                mA/s                mA/s                
E range min (V)     -5.000              -5.000              -5.000              
E range max (V)     5.000               5.000               5.000               
dq                  0.000               1.000               1.000               
unit dq             mA.h                mA.h                mA.h                
dtq (s)             0.0000              120.0000            120.0000            
dQM                 0.000               0.000               0.000               
unit dQM            mA.h                mA.h                mA.h                
dxM                 0.000               0.000               0.000               
delta SoC (%)       pass                pass                pass                
tR (h:m:s)          0:00:10.0000        0:00:0.0000         0:00:0.0000         
dER/dt (mV/h)       0.0                 0.1                 0.1                 
dER (mV)            0.00                0.00                0.00                
dtR (s)             1.0000              120.0000            120.0000            
EL (V)              pass                4.200               3.500               
goto Ns'            0                   0                   1                   
nc cycles           0                   0                   4                   

Technique : 8
Galvanostatic Cycling with Potential Limitation
Ns                  0                   1                   2                   
Set I/C             I                   C x N               C x N               
Is                  0.000               10.000              -10.000             
unit Is             mA                  mA                  mA                  
vs.                 <None>              <None>              <None>              
N                   1.00                1.00                1.00                
I sign              > 0                 > 0                 < 0                 
t1 (h:m:s)          0:00:0.0000         10:00:0.0000        10:00:0.0000        
I Range             10 mA               10 mA               10 mA               
Bandwidth           5                   5                   5                   
dE1 (mV)            0.00                10.00               10.00               
dt1 (s)             0.0000              10.0000             10.0000             
EM (V)              0.000               2.700               0.000               
tM (h:m:s)          0:00:0.0000         0:00:0.0000         0:00:0.0000         
Im                  0.000               0.000               0.000               
unit Im             mA                  mA                  mA                  
dI/dt               0.000               0.000               0.000               
dunit dI/dt         mA/s                mA/s                mA/s                
E range min (V)     -5.000              -5.000              -5.000              
E range max (V)     5.000               5.000               5.000               
dq                  0.000               1.000               1.000               
unit dq             mA.h                mA.h                mA.h                
dtq (s)             0.0000              120.0000            120.0000            
dQM                 0.000               0.000               0.000               
unit dQM            mA.h                mA.h                mA.h                
dxM                 0.000               0.000               0.000               
delta SoC (%)       pass                pass                pass                
tR (h:m:s)          0:00:10.0000        0:00:0.0000         0:00:0.0000         
dER/dt (mV/h)       0.0                 0.1                 0.1                 
dER (mV)            0.00                0.00                0.00                
dtR (s)             1.0000              120.0000            120.0000            
EL (V)              pass                4.200               3.500               
goto Ns'            0                   0                   1                   
nc cycles           0                   0                   4                   

Technique : 9
Galvanostatic Cycling with Potential Limitation
Ns                  0                   1                   2                   
Set I/C             I                   C x N               C x N               
Is                  0.000               10.000              -10.000             
unit Is             mA                  mA                  mA                  
vs.                 <None>              <None>              <None>              
N                   1.00                2.00                2.00                
I sign              > 0                 > 0                 < 0                 
t1 (h:m:s)          0:00:0.0000         10:00:0.0000        10:00:0.0000        
I Range             10 mA               10 mA               10 mA               
Bandwidth           5                   5                   5                   
dE1 (mV)            0.00                10.00               10.00               
dt1 (s)             0.0000              10.0000             10.0000             
EM (V)              0.000               2.700               0.000               
tM (h:m:s)          0:00:0.0000         0:00:0.0000         0:00:0.0000         
Im                  0.000               0.000               0.000               
unit Im             mA                  mA                  mA                  
dI/dt               0.000               0.000               0.000               
dunit dI/dt         mA/s                mA/s                mA/s                
E range min (V)     -5.000              -5.000              -5.000              
E range max (V)     5.000               5.000               5.000               
dq                  0.000               1.000               1.000               
unit dq             mA.h                mA.h                mA.h                
dtq (s)             0.0000              120.0000            120.0000            
dQM                 0.000               0.000               0.000               
unit dQM            mA.h                mA.h                mA.h                
dxM                 0.000               0.000               0.000               
delta SoC (%)       pass                pass                pass                
tR (h:m:s)          0:00:10.0000        0:00:0.0000         0:00:0.0000         
dER/dt (mV/h)       0.0                 0.1                 0.1                 
dER (mV)            0.00                0.00                0.00                
dtR (s)             1.0000              120.0000            120.0000            
EL (V)              pass                4.200               3.500               
goto Ns'            0                   0                   1                   
nc cycles           0                   0                   4                   

Technique : 10
Galvanostatic Cycling with Potential Limitation
Ns                  0                   1                   2                   
Set I/C             I                   C x N               C x N               
Is                  0.000               10.000              -10.000             
unit Is             mA                  mA                  mA                  
vs.                 <None>              <None>              <None>              
N                   1.00                3.00                3.00                
I sign              > 0                 > 0                 < 0                 
t1 (h:m:s)          0:00:0.0000         10:00:0.0000        10:00:0.0000        
I Range             10 mA               10 mA               10 mA               
Bandwidth           5                   5                   5                   
dE1 (mV)            0.00                10.00               2.70                
dt1 (s)             0.0000              10.0000             10.0000             
EM (V)              0.000               2.700               0.000               
tM (h:m:s)          0:00:0.0000         0:00:0.0000         0:00:0.0000         
Im                  0.000               0.000               0.000               
unit Im             mA                  mA                  mA                  
dI/dt               0.000               0.000               0.000               
dunit dI/dt         mA/s                mA/s                mA/s                
E range min (V)     -5.000              -5.000              -5.000              
E range max (V)     5.000               5.000               5.000               
dq                  0.000               1.000               1.000               
unit dq             mA.h                mA.h                mA.h                
dtq (s)             0.0000              120.0000            120.0000            
dQM                 0.000               0.000               0.000               
unit dQM            mA.h                mA.h                mA.h                
dxM                 0.000               0.000               0.000               
delta SoC (%)       pass                pass                pass                
tR (h:m:s)          0:00:10.0000        0:00:0.0000         0:00:0.0000         
dER/dt (mV/h)       0.0                 0.1                 0.1                 
dER (mV)            0.00                0.00                0.00                
dtR (s)             1.0000              120.0000            120.0000            
EL (V)              pass                4.200               3.500               
goto Ns'            0                   0                   1                   
nc cycles           0                   0                   4                   

Technique : 11
Galvanostatic Cycling with Potential Limitation
Ns                  0                   1                   2                   
Set I/C             I                   C x N               C x N               
Is                  0.000               10.000              -10.000             
unit Is             mA                  mA                  mA                  
vs.                 <None>              <None>              <None>              
N                   1.00                4.00                4.00                
I sign              > 0                 > 0                 < 0                 
t1 (h:m:s)          0:00:0.0000         10:00:0.0000        10:00:0.0000        
I Range             10 mA               10 mA               10 mA               
Bandwidth           5                   5                   5                   
dE1 (mV)            0.00                10.00               10.00               
dt1 (s)             0.0000              10.0000             10.0000             
EM (V)              0.000               2.700               0.000               
tM (h:m:s)          0:00:0.0000         0:00:0.0000         0:00:0.0000         
Im                  0.000               0.000               0.000               
unit Im             mA                  mA                  mA                  
dI/dt               0.000               0.000               0.000               
dunit dI/dt         mA/s                mA/s                mA/s                
E range min (V)     -5.000              -5.000              -5.000              
E range max (V)     5.000               5.000               5.000               
dq                  0.000               1.000               1.000               
unit dq             mA.h                mA.h                mA.h                
dtq (s)             0.0000              120.0000            120.0000            
dQM                 0.000               0.000               0.000               
unit dQM            mA.h                mA.h                mA.h                
dxM                 0.000               0.000               0.000               
delta SoC (%)       pass                pass                pass                
tR (h:m:s)          0:00:10.0000        0:00:0.0000         0:00:0.0000         
dER/dt (mV/h)       0.0                 0.1                 0.1                 
dER (mV)            0.00                0.00                0.00                
dtR (s)             1.0000              120.0000            120.0000            
EL (V)              pass                4.200               3.500               
goto Ns'            0                   0                   1                   
nc cycles           0                   0                   4                   

Technique : 12
Galvanostatic Cycling with Potential Limitation
Ns                  0                   1                   2                   
Set I/C             I                   C x N               C x N               
Is                  0.000               10.000              -10.000             
unit Is             mA                  mA                  mA                  
vs.                 <None>              <None>              <None>              
N                   1.00                5.00                5.00                
I sign              > 0                 > 0                 < 0                 
t1 (h:m:s)          0:00:0.0000         10:00:0.0000        10:00:0.0000        
I Range             10 mA               10 mA               10 mA               
Bandwidth           5                   5                   5                   
dE1 (mV)            0.00                10.00               10.00               
dt1 (s)             0.0000              10.0000             10.0000             
EM (V)              0.000               2.700               0.000               
tM (h:m:s)          0:00:0.0000         0:00:0.0000         0:00:0.0000         
Im                  0.000               0.000               0.000               
unit Im             mA                  mA                  mA                  
dI/dt               0.000               0.000               0.000               
dunit dI/dt         mA/s                mA/s                mA/s                
E range min (V)     -5.000              -5.000              -5.000              
E range max (V)     5.000               5.000               5.000               
dq                  0.000               1.000               1.000               
unit dq             mA.h                mA.h                mA.h                
dtq (s)             0.0000              120.0000            120.0000            
dQM                 0.000               0.000               0.000               
unit dQM            mA.h                mA.h                mA.h                
dxM                 0.000               0.000               0.000               
delta SoC (%)       pass                pass                pass                
tR (h:m:s)          0:00:10.0000        0:00:0.0000         0:00:0.0000         
dER/dt (mV/h)       0.0                 0.1                 0.1                 
dER (mV)            0.00                0.00                0.00                
dtR (s)             1.0000              120.0000            120.0000            
EL (V)              pass                4.200               3.500               
goto Ns'            0                   0                   1                   
nc cycles           0                   0                   4                   

Technique : 13
Galvanostatic Cycling with Potential Limitation
Ns                  0                   1                   2                   
Set I/C             I                   C x N               C x N               
Is                  0.000               6.000               -10.000             
unit Is             mA                  mA                  mA                  
vs.                 <None>              <None>              <None>              
N                   1.00                6.00                6.00                
I sign              > 0                 > 0                 < 0                 
t1 (h:m:s)          0:00:0.0000         10:00:0.0000        10:00:0.0000        
I Range             100 mA              100 mA              100 mA              
Bandwidth           5                   5                   5                   
dE1 (mV)            0.00                10.00               10.00               
dt1 (s)             0.0000              10.0000             10.0000             
EM (V)              0.000               2.700               0.000               
tM (h:m:s)          0:00:0.0000         0:00:0.0000         0:00:0.0000         
Im                  0.000               0.000               0.000               
unit Im             mA                  mA                  mA                  
dI/dt               0.000               0.000               0.000               
dunit dI/dt         mA/s                mA/s                mA/s                
E range min (V)     -5.000              -5.000              -5.000              
E range max (V)     5.000               5.000               5.000               
dq                  0.000               1.000               1.000               
unit dq             mA.h                mA.h                mA.h                
dtq (s)             0.0000              120.0000            120.0000            
dQM                 0.000               0.000               0.000               
unit dQM            mA.h                mA.h                mA.h                
dxM                 0.000               0.000               0.000               
delta SoC (%)       pass                pass                pass                
tR (h:m:s)          0:00:10.0000        0:00:0.0000         0:00:0.0000         
dER/dt (mV/h)       0.0                 0.1                 0.1                 
dER (mV)            0.00                0.00                0.00                
dtR (s)             1.0000              120.0000            120.0000            
EL (V)              pass                4.200               3.500               
goto Ns'            0                   0                   1                   
nc cycles           0                   0                   4                   

Technique : 14
Galvanostatic Cycling with Potential Limitation
Ns                  0                   1                   2                   
Set I/C             I                   C x N               C x N               
Is                  0.000               10.000              -10.000             
unit Is             mA                  mA                  mA                  
vs.                 <None>              <None>              <None>              
N                   1.00                7.00                7.00                
I sign              > 0                 > 0                 < 0                 
t1 (h:m:s)          0:00:0.0000         10:00:0.0000        10:00:0.0000        
I Range             100 mA              100 mA              100 mA              
Bandwidth           5                   5                   5                   
dE1 (mV)            0.00                10.00               10.00               
dt1 (s)             0.0000              10.0000             10.0000             
EM (V)              0.000               2.700               0.000               
tM (h:m:s)          0:00:0.0000         0:00:0.0000         0:00:0.0000         
Im                  0.000               0.000               0.000               
unit Im             mA                  mA                  mA                  
dI/dt               0.000               0.000               0.000               
dunit dI/dt         mA/s                mA/s                mA/s                
E range min (V)     -5.000              -5.000              -5.000              
E range max (V)     5.000               5.000               5.000               
dq                  0.000               1.000               1.000               
unit dq             mA.h                mA.h                mA.h                
dtq (s)             0.0000              120.0000            120.0000            
dQM                 0.000               0.000               0.000               
unit dQM            mA.h                mA.h                mA.h                
dxM                 0.000               0.000               0.000               
delta SoC (%)       pass                pass                pass                
tR (h:m:s)          0:00:10.0000        0:00:0.0000         0:00:0.0000         
dER/dt (mV/h)       0.0                 0.1                 0.1                 
dER (mV)            0.00                0.00                0.00                
dtR (s)             1.0000              120.0000            120.0000            
EL (V)              pass                4.200               3.500               
goto Ns'            0                   0                   1                   
nc cycles           0                   0                   4                   

Technique : 15
Galvanostatic Cycling with Potential Limitation
Ns                  0                   1                   2                   
Set I/C             I                   C x N               C x N               
Is                  0.000               10.000              -10.000             
unit Is             mA                  mA                  mA                  
vs.                 <None>              <None>              <None>              
N                   1.00                8.00                8.00                
I sign              > 0                 > 0                 < 0                 
t1 (h:m:s)          0:00:0.0000         10:00:0.0000        10:00:0.0000        
I Range             100 mA              100 mA              100 mA              
Bandwidth           5                   5                   5                   
dE1 (mV)            0.00                10.00               10.00               
dt1 (s)             0.0000              10.0000             10.0000             
EM (V)              0.000               2.700               0.000               
tM (h:m:s)          0:00:0.0000         0:00:0.0000         0:00:0.0000         
Im                  0.000               0.000               0.000               
unit Im             mA                  mA                  mA                  
dI/dt               0.000               0.000               0.000               
dunit dI/dt         mA/s                mA/s                mA/s                
E range min (V)     -5.000              -5.000              -5.000              
E range max (V)     5.000               5.000               5.000               
dq                  0.000               1.000               1.000               
unit dq             mA.h                mA.h                mA.h                
dtq (s)             0.0000              120.0000            120.0000            
dQM                 0.000               0.000               0.000               
unit dQM            mA.h                mA.h                mA.h                
dxM                 0.000               0.000               0.000               
delta SoC (%)       pass                pass                pass                
tR (h:m:s)          0:00:10.0000        0:00:0.0000         0:00:0.0000         
dER/dt (mV/h)       0.0                 0.1                 0.1                 
dER (mV)            0.00                0.00                0.00                
dtR (s)             1.0000              120.0000            120.0000            
EL (V)              pass                4.200               3.500               
goto Ns'            0                   0                   1                   
nc cycles           0                   0                   4                   

Technique : 16
Galvanostatic Cycling with Potential Limitation
Ns                  0                   1                   2                   
Set I/C             I                   C x N               C x N               
Is                  0.000               10.000              -10.000             
unit Is             mA                  mA                  mA                  
vs.                 <None>              <None>              <None>              
N                   1.00                9.00                9.00                
I sign              > 0                 > 0                 < 0                 
t1 (h:m:s)          0:00:0.0000         10:00:0.0000        10:00:0.0000        
I Range             100 mA              100 mA              100 mA              
Bandwidth           5                   5                   5                   
dE1 (mV)            0.00                10.00               10.00               
dt1 (s)             0.0000              10.0000             10.0000             
EM (V)              0.000               2.700               0.000               
tM (h:m:s)          0:00:0.0000         0:00:0.0000         0:00:0.0000         
Im                  0.000               0.000               0.000               
unit Im             mA                  mA                  mA                  
dI/dt               0.000               0.000               0.000               
dunit dI/dt         mA/s                mA/s                mA/s                
E range min (V)     -5.000              -5.000              -5.000              
E range max (V)     5.000               5.000               5.000               
dq                  0.000               1.000               1.000               
unit dq             mA.h                mA.h                mA.h                
dtq (s)             0.0000              120.0000            120.0000            
dQM                 0.000               0.000               0.000               
unit dQM            mA.h                mA.h                mA.h                
dxM                 0.000               0.000               0.000               
delta SoC (%)       pass                pass                pass                
tR (h:m:s)          0:00:10.0000        0:00:0.0000         0:00:0.0000         
dER/dt (mV/h)       0.0                 0.1                 0.1                 
dER (mV)            0.00                0.00                0.00                
dtR (s)             1.0000              120.0000            120.0000            
EL (V)              pass                4.200               3.500               
goto Ns'            0                   0                   1                   
nc cycles           0                   0                   4                   

Technique : 17
Galvanostatic Cycling with Potential Limitation
Ns                  0                   1                   2                   
Set I/C             I                   C x N               C x N               
Is                  0.000               10.000              -10.000             
unit Is             mA                  mA                  mA                  
vs.                 <None>              <None>              <None>              
N                   1.00                10.00               10.00               
I sign              > 0                 > 0                 < 0                 
t1 (h:m:s)          0:00:0.0000         10:00:0.0000        10:00:0.0000        
I Range             100 mA              100 mA              100 mA              
Bandwidth           5                   5                   5                   
dE1 (mV)            0.00                10.00               10.00               
dt1 (s)             0.0000              10.0000             10.0000             
EM (V)              0.000               2.700               0.000               
tM (h:m:s)          0:00:0.0000         0:00:0.0000         0:00:0.0000         
Im                  0.000               0.000               0.000               
unit Im             mA                  mA                  mA                  
dI/dt               0.000               0.000               0.000               
dunit dI/dt         mA/s                mA/s                mA/s                
E range min (V)     -5.000              -5.000              -5.000              
E range max (V)     5.000               5.000               5.000               
dq                  0.000               1.000               1.000               
unit dq             mA.h                mA.h                mA.h                
dtq (s)             0.0000              120.0000            120.0000            
dQM                 0.000               0.000               0.000               
unit dQM            mA.h                mA.h                mA.h                
dxM                 0.000               0.000               0.000               
delta SoC (%)       pass                pass                pass                
tR (h:m:s)          0:00:10.0000        0:00:0.0000         0:00:0.0000         
dER/dt (mV/h)       0.0                 0.1                 0.1                 
dER (mV)            0.00                0.00                0.00                
dtR (s)             1.0000              120.0000            120.0000            
EL (V)              pass                4.200               3.500               
goto Ns'            0                   0                   1                   
nc cycles           0                   0                   4                   

Technique : 18
Galvanostatic Cycling with Potential Limitation
Ns                  0                   1                   2                   
Set I/C             I                   C x N               C x N               
Is                  0.000               10.000              -10.000             
unit Is             mA                  mA                  mA                  
vs.                 <None>              <None>              <None>              
N                   1.00                20.00               20.00               
I sign              > 0                 > 0                 < 0                 
t1 (h:m:s)          0:00:0.0000         10:00:0.0000        10:00:0.0000        
I Range             100 mA              100 mA              100 mA              
Bandwidth           5                   5                   5                   
dE1 (mV)            0.00                10.00               10.00               
dt1 (s)             0.0000              10.0000             10.0000             
EM (V)              0.000               2.700               0.000               
tM (h:m:s)          0:00:0.0000         0:00:0.0000         0:00:0.0000         
Im                  0.000               0.000               0.000               
unit Im             mA                  mA                  mA                  
dI/dt               0.000               0.000               0.000               
dunit dI/dt         mA/s                mA/s                mA/s                
E range min (V)     -5.000              -5.000              -5.000              
E range max (V)     5.000               5.000               5.000               
dq                  0.000               1.000               1.000               
unit dq             mA.h                mA.h                mA.h                
dtq (s)             0.0000              120.0000            120.0000            
dQM                 0.000               0.000               0.000               
unit dQM            mA.h                mA.h                mA.h                
dxM                 0.000               0.000               0.000               
delta SoC (%)       pass                pass                pass                
tR (h:m:s)          0:00:10.0000        0:00:0.0000         0:00:0.0000         
dER/dt (mV/h)       0.0                 0.1                 0.1                 
dER (mV)            0.00                0.00                0.00                
dtR (s)             1.0000              120.0000            120.0000            
EL (V)              pass                4.200               3.500               
goto Ns'            0                   0                   1                   
nc cycles           0                   0                   4                   
