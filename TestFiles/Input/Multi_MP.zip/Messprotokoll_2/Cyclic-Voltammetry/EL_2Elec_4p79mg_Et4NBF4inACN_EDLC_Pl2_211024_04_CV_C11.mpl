EC-Lab LOG FILE

Cyclic Voltammetry

Run on channel : 11 (SN 44072)
User : 
CE vs. WE compliance from -10 V to 10 V
Electrode connection : standard
Potential control : Ewe-Ece
Ewe ctrl range : min = -5.00 V, max = 5.00 V
Safety Limits :
	Do not start on E overload
Acquisition started on : 10/21/2024 13:34:20.138
Loaded Setting File : NONE
Saved on :
	File : EL_2Elec_4p79mg_Et4NBF4inACN_EDLC_Pl2_211024_04_CV_C11.mpr
	Directory : D:\Eleonora\EDLC\EL_2Elec_4p79mg_Et4NBF4inACN_EDLC_Pl2_211024\
	Host : 192.109.209.129
Device : MPG-2 (SN 0271)
Address : 192.109.209.128
EC-Lab for windows v11.43 (software)
Internet server v11.40 (firmware)
Command interpretor v11.40 (firmware)
Electrode material : Activated carbon
Initial state : uncharged
Electrolyte : 1M TEABF4 in ACN
Comments : CV and GCPL
Mass of active material : 1.000 mg
 at x = 1.000
Molecular weight of active material (at x = 0) : 12.000 g/mol
Atomic weight of intercalated ion : 0.001 g/mol
Acquisition started at : xo = 0.000
Number of e- transfered per intercalated ion : 1
for DX = 1, DQ = 2.233 mA.h
Battery capacity : 4.790 mA.h
Electrode surface area : 1.131 cm�
Characteristic mass : 4.790 mg
Volume (V) : 1.131 cm�
Record Ece
Record Power
Cycle Definition : Charge/Discharge alternance
Ei (V)              0.000               
vs.                 Emeas               
dE/dt               20.000              
dE/dt unit          mV/s                
E1 (V)              2.700               
vs.                 Ref                 
Step percent        50                  
N                   10                  
E range min (V)     -5.000              
E range max (V)     5.000               
I Range             Auto                
I Range min         Unset               
I Range max         Unset               
I Range init        Unset               
Bandwidth           4                   
E2 (V)              0.000               
vs.                 Ref                 
nc cycles           9                   
Reverse Scan        0                   
Ef (V)              0.000               
vs.                 Eoc                 
