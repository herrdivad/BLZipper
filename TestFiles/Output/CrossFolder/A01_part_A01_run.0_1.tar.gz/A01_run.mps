MPS belongs to Cell_01 -- noRealData
