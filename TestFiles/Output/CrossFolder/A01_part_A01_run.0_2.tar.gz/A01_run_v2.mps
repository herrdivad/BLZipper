MPS belongs to Cell_02 (v2) -- noRealData
